/*******************************************************
* Name: Christa Fox
* Course: CSIS 1410
* Assignment: A04
*******************************************************/

package a04;

public interface Printable extends Shape
{
	//feilds
	
	//ctors
	
	//methods
	StringBuilder print();
	
}
