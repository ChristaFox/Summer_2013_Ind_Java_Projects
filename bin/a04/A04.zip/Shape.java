/*******************************************************
* Name: Christa Fox
* Course: CSIS 1410
* Assignment: A04
*******************************************************/

package a04;

public interface Shape 
{
	//feilds
	
	//ctors
	
	//methods
	double perimeter();
	
	double area();
	
}
