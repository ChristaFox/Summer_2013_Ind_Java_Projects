/*******************************************************
* Name: Christa Fox
* Course: CSIS 1410
* Assignment: A05
*******************************************************/

package a05;

import javax.swing.JFrame;

public class FaceApp
{
	public static void main(String[] args) 
	{
	        FaceMaker frame = new FaceMaker();
	        frame.setSize(1000, 800);
	        frame.setLocationRelativeTo(null);
	        frame.setVisible(true);
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
