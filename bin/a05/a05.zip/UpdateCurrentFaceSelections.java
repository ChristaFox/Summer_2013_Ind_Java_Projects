/*******************************************************
* Name: Christa Fox
* Course: CSIS 1410
* Assignment: A05
*******************************************************/

package a05;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.AbstractButton;
import javax.swing.JCheckBox;

abstract class UpdateCurrentFaceSelections implements ItemListener
{
	public void itemStateChanged(ItemEvent event) 
	{
		JCheckBox eyesCheckBox;
		
		if(eyesCheckBox.isSelected() == false && FaceController.nose.isSelected() == false && FaceController.mouth.isSelected() == false)
		{
			FaceController.faceCounter++;
		}
		else
		{
			if(eyes.isSelected() == true)
			{
				eyesCounter++;
			}
			
			if(noseChecked == true)
			{
				noseCounter++;
			}
			
			if(mouthChecked == true)
			{
				mouthCounter++;
			}
		
	}
}
}
