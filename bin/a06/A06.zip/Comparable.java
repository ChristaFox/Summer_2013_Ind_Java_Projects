/*******************************************************
* Name: Christa Fox
* Course: CSIS 1410
* Assignment: A06
*******************************************************/
package a06;

public interface Comparable 
{	
	int compareTo(Friend other);

	boolean equals(Object obj);

}
